# -*- coding: utf-8 -*-
"""
Created on Mon Jun  4 15:00:41 2018

@author: Matthew Tarchick
"""
import os
import cv2
from scipy import signal
import numpy as np
import argparse
from tkinter.filedialog import askopenfilename
import matplotlib.pyplot as plt 
import subprocess
import time

def parse_frames(image_file, verbose):
    cap = cv2.VideoCapture(image_file)
    if verbose:print("Video successfully loaded")
    FRAME_COUNT = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    if verbose > 1: 
        FPS = cap.get(cv2.CAP_PROP_FPS)
        FRAME_HEIGHT = cap.get(cv2.CAP_PROP_FRAME_HEIGHT)
        FRAME_WIDTH  = cap.get(cv2.CAP_PROP_FRAME_WIDTH)
        print("INFO: \n Frame count: ", FRAME_COUNT, "\n",
             "FPS: ", FPS, " \n", 
             "FRAME_HEIGHT: ", FRAME_HEIGHT, " \n",
             "FRAME_WIDTH: ", FRAME_WIDTH, " \n",)
    for i in range(FRAME_COUNT):
        a, img = cap.read()
        lazer_image = img[:,:,1]        
        yield translate_frame(lazer_image)
        
    cap.release()

def translate_frame(img):
    point_array = np.argmax(img, axis = 0)    
    #filter out green points
    #convert 2D matrix into single vector of points
    #spline/filter data to remove any jumps
    return point_array



def cwt_vector(vec_arr, verbose,  widths, wavelet = signal.ricker):
    widths = np.arange(1,widths)
    for i in range(len(vec_arr)):
        if verbose >= 2:
            print("Frame {} of {} analyzed".format(i, len(vec_arr)))
            print('*'*int((i/len(vec_arr))*100))
        cwtmatr =  signal.cwt(vec_arr[i], wavelet, widths)       
        yield cwtmatr

def write_video(list_arr, verbose, vid_name, directory,  rate = 10):
    if directory == None:
        directory = os.getcwd() + '\\images\\'
    
    if not os.path.exists(directory):
        os.makedirs(directory)
    
    for i in range(len(list_arr)):
        if verbose >= 2: print("Spectra {} of {} saved".format(i, len(list_arr)))
        if verbose >= 2: print('*'*int((i/len(list_arr))*100))
        plt.imshow(list_arr[i], aspect = 10)
        plt.savefig(directory+'myfig-{}.png'.format(i), bbox = 'tight')
    
    if verbose >= 1: print('All images saved')
    open_dir = directory + 'myfig-%d.png'
    save_dir = directory + vid_name
    subprocess.check_call(['ffmpeg', 
                           '-i', open_dir, 
                           '-vcodec', 'mpeg4', 
                           '-qscale', '2',
                           '-async', '44100',
                           '-y',save_dir])
#hyperparameters
#def ffmpeg_func()


if __name__ == '__main__':
    
    parser = argparse.ArgumentParser(description = "Wavlet analysis file outputter")
    
    parser.add_argument('-v', '--verbosity', action = 'count', 
                        help = "Levels: 0) nothing 1) function success 2) function progress and details 3) Elapsed time"
                       )
    
    parser.add_argument('-ws', '--widths', type = int, help = 'The number of scales the CWT will use')
    parser.add_argument('-o', '--output', help = 'The location where the file will be saved')
    parser.add_argument('-vid', '--videoname', help = 'The name of the video to output')
    
    args = parser.parse_args()
    
    verbose = 0
    if args.verbosity != None:
        verbose = int(args.verbosity)

    widths = 31
    if args.widths != None:
        widths = args.widths
 
    output = args.output
        
    videoname = 'myvid.mp4'
    if args.videoname != None:
        videoname = args.videoname
    
    if verbose >= 1: print("Select a input file as a video file (.mpg .mp4. avi)")
    input_file = askopenfilename()#"C:/pyscripts/Images/PhrynomantisWalk.mpg" #
    
    if verbose >= 1: print("File {} successfully loaded".format(input_file)) 
    #CODE FOR TAKING IN DATA
    frame_to_vec = list(parse_frames(input_file, verbose))
    if verbose >= 1: print('{} frames successfully parsed'.format(len(frame_to_vec)))

    
    #CODE FOR ANALYZING DATA
    a_start = time.time()
    vec_to_spect = list(cwt_vector(frame_to_vec, verbose, widths))
    if verbose >= 1: print('{} scales analyzed'.format(vec_to_spect[0].shape[0]))
    a_end = time.time()
    if verbose >= 3: print("Total analysis time = {}".format(abs(a_start - a_end)))
    #TODO: Determine how to output a csv and what needs to go in the csv

    #CODE FOR OUTPUTTING DATA
    w_start = time.time()
    write_video(vec_to_spect, verbose, videoname, output)
    if verbose >= 1: print('Movie file written to {}'.format(input_file))
    w_end = time.time()
    if verbose >= 3: print("Total write time = {}".format(abs(w_start - w_end)))

    #plt.imshow(vec_to_spect[10], aspect = 'auto')
    #plt.show()
    