*Note this works for windows. 
*********************README********************
*1) Download file wavelet_analysis.zip
*
*2) Extract to destination of your choosing 
*
*3) Download and install Anaconda
*	a) https://www.anaconda.com/download/
*
*4) Ensure ffmpeg is installed
*	a) visit https://ffmpeg.zeranoe.com/builds/
*	b) pick the correct build
*	c) into the cmd paste this code:
*		i) setx /M PATH "path\to\ffmpeg\bin;%PATH%"
*		i) replace path\to\ with the preferred path of ffmpeg
*	
*4) Make sure all dependencies are installed:
*	a) numpy
*	b) openCV2
*	c) scipy
*
*5) Open command terminal and mount the file where wavelet_analysis was extracted
*	>>>cd c:/pyscripts/wavelet_analysis
*
*6) Using the command "Python" run the script wavelet_analysis.py
*	>>>python wavelet_analysis.py
*
*@ OPTIONS
* -h displays all options
* -v determines the level of detail in the cmd prompt
* -ws determines how many scales the CWT will output
* -o determines where the file will output to, defaults to directory that was opened
* -vid determines the name of the video file that is saved. 